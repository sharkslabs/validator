VERSION="v0.605.20216"
URL="--url https://empty-hardworking-leaf.solana-testnet.quiknode.pro/a35a7b6167a7fcb5e537f03d8adda54caa5c6c6c"
git clone --recurse-submodules https://github.com/firedancer-io/firedancer.git
pushd firedancer
git checkout $VERSION
curl https://sh.rustup.rs -sSf | sh -s -- -y
. "$HOME/.cargo/env"
bash deps.sh
EXTRAS="openssl" make -j fdctl
popd
sh -c "$(curl -sSfL https://release.anza.xyz/v2.0.2/install)"
export PATH="/home/firedancer/.local/share/solana/install/active_release/bin:$PATH"
agave-install init v2.3.2
solana config set --keypair data/validator-keypair.json
solana config set --url https://empty-hardworking-leaf.solana-testnet.quiknode.pro/a35a7b6167a7fcb5e537f03d8adda54caa5c6c6c
solana-keygen new -o data/w.json
solana-keygen new -o data/selfstake-account.json
pushd ./data

solana create-vote-account --url https://empty-hardworking-leaf.solana-testnet.quiknode.pro/a35a7b6167a7fcb5e537f03d8adda54caa5c6c6c --fee-payer ./validator-keypair.json ./vote-account-keypair.json ./validator-keypair.json ./w.json
solana transfer --allow-unfunded-recipient --url https://empty-hardworking-leaf.solana-testnet.quiknode.pro/a35a7b6167a7fcb5e537f03d8adda54caa5c6c6c w.json 3
solana create-stake-account --url https://empty-hardworking-leaf.solana-testnet.quiknode.pro/a35a7b6167a7fcb5e537f03d8adda54caa5c6c6c selfstake-account.json 2.5 --from w.json --fee-payer validator-keypair.json
solana --url https://empty-hardworking-leaf.solana-testnet.quiknode.pro/a35a7b6167a7fcb5e537f03d8adda54caa5c6c6c delegate-stake selfstake-account.json vote-account-keypair.json --keypair w.json

popd

sudo chown firedancer:firedancer -R /mnt/ledger/
sudo chown firedancer:firedancer -R /mnt/accounts/

pushd /mnt/ledger
aria2c -x16 -s16 --force-sequential=true                  https://snapshots.avorio.network/testnet/snapshot.tar.bz2                  https://snapshots.avorio.network/testnet/incremental-snapshot.tar.bz2
popd

sudo systemctl start validator && sudo journalctl -u validator -f -e
