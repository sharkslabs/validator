apt-get -y update
apt install -y linux-tools-common
cpupower frequency-set --governor performance
apt install aria2 -y

mkfs.xfs /dev/nvme0n1
mkfs.xfs /dev/nvme1n1

mkdir /mnt/ledger
mkdir /mnt/accounts

mount /dev/nvme0n1 /mnt/ledger
mount /dev/nvme1n1 /mnt/accounts


adduser firedancer --disabled-password --gecos ""
usermod -aG sudo firedancer

echo "firedancer ALL=(ALL) NOPASSWD: ALL" | sudo tee -a /etc/sudoers

chown firedancer:firedancer -R /mnt/ledger
chown firedancer:firedancer -R /mnt/accounts

ufw allow ssh
ufw allow http
ufw allow 8000:8020/udp
ufw allow 8000:8020/tcp
ufw allow 8900:9000/udp
ufw allow 8900:9000/tcp

mkdir /home/firedancer/data
chown firedancer:firedancer -R /home/firedancer/data

cp app.toml /home/firedancer
cp validator-keypair.json /home/firedancer/data
cp vote-account-keypair.json /home/firedancer/data
cp firedancer.sh /home/firedancer

chmod +x /home/firedancer/firedancer.sh
chown firedancer:firedancer -R /home/firedancer/data

cp validator.service /etc/systemd/system
