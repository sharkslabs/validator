#!/bin/bash

read -p "Enter IP: " IP 

agave-validator -l /mnt/ledger wait-for-restart-window --min-idle-time 2 --skip-new-snapshot-check
fdctl set-identity /home/firedancer/data/unstaked-identity.json --config /home/firedancer/app.toml
ln -sf /home/firedancer/data/unstaked-identity.json /home/firedancer/identity.json
scp /mnt/ledger/tower-1_9-$(solana-keygen pubkey /home/firedancer/data/staked-identity.json).bin firedancer@$IP:/mnt/ledger