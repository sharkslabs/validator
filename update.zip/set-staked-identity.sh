#!/bin/bash
fdctl set-identity --require-tower --config /home/firedancer/app.toml /home/firedancer/data/staked-identity.json
ln -sf /home/firedancer/data/staked-identity.json /home/firedancer/identity.json