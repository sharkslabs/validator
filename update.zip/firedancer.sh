VERSION="v0.708.20306"
URL="--url https://mainnet.helius-rpc.com/?api-key=98556073-aa57-4283-81f9-f5680af77914"

git clone --recurse-submodules https://github.com/firedancer-io/firedancer.git

pushd firedancer
git checkout $VERSION
curl https://sh.rustup.rs -sSf | sh -s -- -y
. "$HOME/.cargo/env"
bash deps.sh
EXTRAS="openssl" make -j fdctl
popd

echo "export PATH=/bin:/usr/bin:/home/firedancer/firedancer/build/native/gcc/bin" | tee -a ~/.bashrc
echo "export PATH=/bin:/usr/bin:/home/firedancer/.local/share/solana/install/active_release/bin" | tee -a ~/.bashrc

sh -c "$(curl -sSfL https://release.anza.xyz/v2.0.2/install)"
export PATH="/home/firedancer/.local/share/solana/install/active_release/bin:$PATH"
agave-install init v2.3.2


pushd ./data
touch staked-identity.json
touch vote-account-keypair.json
solana-keygen new -o unstaked-identity.json
popd

solana config set $URL

ln -sf /home/firedancer/data/unstaked-identity.json /home/firedancer/identity.json

solana config set --keypair /home/firedancer/data/staked-identity.json

sudo chown firedancer:firedancer -R /mnt/ledger/
sudo chown firedancer:firedancer -R /mnt/accounts/

sudo ./firedancer/build/native/gcc/bin/fdctl configure init all --config /home/firedancer/app.toml

aria2c --auto-file-renaming=false https://obj.sharklabs.sh/public/snap-fetch

sudo chmod +x snap-fetch