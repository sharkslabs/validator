scp firedancer@149.28.44.18:/mnt/ledger/contact-info.bin /mnt/ledger
scp firedancer@149.28.44.18:/mnt/ledger/genesis.bin /mnt/ledger

./snap-fetch -c 32 -s 20971520 --chunks-per-file 40 -o /mnt/ledger --skip-existing

sudo systemctl start validator && sudo journalctl -u validator -f -e
