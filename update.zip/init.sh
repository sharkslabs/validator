LEDGER_DISK="/dev/nvme0n1"
ACCOUNTS_DISK="/dev/nvme1n1"
apt-get -y update
apt-get -y upgrade
apt install -y linux-tools-common
apt install -y linux-tools-generic
cpupower frequency-set --governor performance
apt install aria2 -y
apt-get install -y libclang-dev libudev-dev protobuf-compiler

mkfs.xfs $LEDGER_DISK
mkfs.xfs $ACCOUNTS_DISK

mkdir /mnt/ledger
mkdir /mnt/accounts

mount $LEDGER_DISK /mnt/ledger
mount $ACCOUNTS_DISK /mnt/accounts

echo "$LEDGER_DISK /mnt/ledger xfs defaults 0 1" | sudo tee -a /etc/fstab
echo "$ACCOUNTS_DISK /mnt/accounts xfs defaults 0 1" | sudo tee -a /etc/fstab

adduser firedancer --disabled-password --gecos ""
usermod -aG sudo firedancer
passwd firedancer
echo "firedancer ALL=(ALL) NOPASSWD: ALL" | sudo tee -a /etc/sudoers

chown firedancer:firedancer -R /mnt/ledger
chown firedancer:firedancer -R /mnt/accounts

sudo bash -c "cat >/etc/sysctl.d/21-agave-validator.conf <<EOF
# Increase max UDP buffer sizes
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728

# Increase memory mapped files limit
vm.max_map_count = 1000000

# Increase number of allowed open file descriptors
fs.nr_open = 1000000
EOF"

sudo sysctl -p /etc/sysctl.d/21-agave-validator.conf

ufw allow ssh
ufw allow http
ufw allow 8000:8020/udp
ufw allow 8000:8020/tcp
ufw allow 8900:9000/udp
ufw allow 8900:9000/tcp

mkdir /home/firedancer/data
sudo mkdir /home/firedancer/.ssh && echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK2cVehL0rI18TIObdnkSC4555jIbWrqFMAUNORQmB4Q moranmr8@gmail.com" | sudo tee -a /home/firedancer/.ssh/authorized_keys
cp app.toml /home/firedancer
cp *.sh /home/firedancer

chmod +x /home/firedancer/*.sh
chown firedancer:firedancer -R /home/firedancer/data

cp validator.service /etc/systemd/system