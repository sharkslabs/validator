#!/bin/bash

# Constants - String maps (associative arrays)
# University IPs - Update these with your actual server IPs
declare -A UNIVERSITY_IPS=(
    ["Princeton University"]="66.165.230.30"
    ["University of Pennsylvania"]="66.165.237.46"
    ["Duke's Fuqua School of Business"]="66.165.251.234"
    ["Columbia University"]="66.165.251.126"
    ["Dartmouth College"]="66.165.233.210"
    ["Vanderbilt University"]="66.165.233.214"
    ["UC Berkeley"]="66.165.245.242"
    ["Emory University"]="66.165.246.214"
    ["University of Southern California"]="23.92.67.234"
    ["University of Illinois"]="66.165.251.238"
    ["Rutgers University"]="66.165.251.122"
    ["Purdue University"]="23.92.67.238"
    ["University of Minnesota"]="66.165.233.62"
    ["Villanova University"]="66.165.233.74"
    ["University of Oregon"]="66.165.233.78"
    ["California State University - Fullerton"]="66.165.233.98"
    ["University of Waterloo"]="66.165.233.102"
    ["Georgia Institute of Technology"]="66.165.233.114"
    ["Dalhousie University"]="66.165.233.118"
    ["University of Michigan"]="66.165.233.58"
)

# First string map: University name to staked-identity public address (Mainnet-Beta)
declare -A STAKED_IDENTITY_ADDRESSES=(
    ["Princeton University"]="5LNEDitSMhApT2uFnmtN7FmjCiGuatpnb2uU4f3shrk"
    ["University of Pennsylvania"]="HBhWr2MXcBjuhJAfwei8N6cK588Y7zBwmAg13RPshrk"
    ["Duke's Fuqua School of Business"]="Ec2vpRp8HsTXndg25eBNJTQcQxTdEbhutivLQQLshrk"
    ["Columbia University"]="q1yPXLsYcJhzxhUYLewFDjYmsBh2gDFnYqrZ9VPshrk"
    ["Dartmouth College"]="WnP8cbMW3fqZLHiyEWSpjBQ6sZpfPustpaiY4QKshrk"
    ["Vanderbilt University"]="BXoNGzhaW2R71avxDbMofBTnqH9FMsQmXVAXR1Xshrk"
    ["UC Berkeley"]="Sp7stYmvQaALhVEsmbV3NnatVrH7DFJUz6PWYJfshrk"
    ["Emory University"]="XAqHfPFsqTfAJHBRHAcEECkMSykXjkUj2Rta16Qshrk"
    ["University of Southern California"]="eKV6p4xW86Ryc3r93WYLEHhHne7Zzn3upT8R2cxshrk"
    ["University of Illinois"]="s9bQfWdGJSTr8zHcFrDbuXpc2SgjS5jZvaor3t1shrk"
    ["Rutgers University"]="kREnNfJrPEHbrjSQDxmxZdGmN6hi7ewXZ3UZTURshrk"
    ["Purdue University"]="cBYbGeACrgaqNNoE1zFTveRZGozE6G4q6X6ntnCshrk"
    ["University of Minnesota"]="12i8gndWWWMTRzJBFhnYkobNgZB3XMUUJq75HeUrshrk"
    ["Villanova University"]="U82KEYMnuCiZSQbvuCJTZ652HX9NQ63uNSnxyucshrk"
    ["University of Oregon"]="5N8rWeZbNWLJDYTohNfpH4JAXiPhnicVYKrucW1shrk"
    ["California State University - Fullerton"]="vE8K2TUzwD9NAiTcDjGx6rF8aqU7s3mYtvCmQjHshrk"
    ["University of Waterloo"]="uxqVAFQfox97HazsPtkKiwhypQH6jEGXkQBHDtXshrk"
    ["Georgia Institute of Technology"]="13DmVBcyrSdsSsLWaKH9x1dwxDf48Wu5wprwxMmLshrk"
    ["Dalhousie University"]="BSMe78Jk1BfeJDdHQj1aXVjrT2aMAYidyNAGQsTshrk"
    ["University of Michigan"]="DDgVWafunwNr1YeJD89SWqotXuwjzyvZRmpapZPshrk"
)

# Second string map: University name to vote-account public address (from CSV)
declare -A VOTE_ACCOUNT_ADDRESSES=(
    ["Princeton University"]="ksQuu3JAStVXUeDCHeW6QtVRHNMcdtgPyepUd3Yshrk"
    ["University of Pennsylvania"]="xLEM6v9xaZ6Mb8SBQjf6ryHpRVxMngdWepbzMUashrk"
    ["Duke's Fuqua School of Business"]="PT7kgZzgqUzbkHnQ2asoBtA73iuE69JsPkcKsk9shrk"
    ["Columbia University"]="FRqYRkp3tUoBc62pnabeX8SVr6p3v6HM2tzT2NVshrk"
    ["Dartmouth College"]="g3YCFRjDBQDv44XtPT6dfGvhrB9DE75zLMybq9Mshrk"
    ["Vanderbilt University"]="1iD1fPWCyr7VmEwZ9ShtmiK98D4KTSSwXwbA3CDshrk"
    ["UC Berkeley"]="xtA5ixQt5rvEHfqfGGJkdKqoV9TH14NPfkhsdXsshrk"
    ["Emory University"]="ySxF6XaSFSwU46iJbgyh2rAW5jagLbYULPtWvZCshrk"
    ["University of Southern California"]="BUgQ241MWNkRGwEYww4VNtLxTZNb92YUzxwtNx7shrk"
    ["University of Illinois"]="Hcdhp5ovmEUEcyBZwv1DAZ5xz727fpZwujFaKCzshrk"
    ["Rutgers University"]="FH5SX1WUubW9nD1rweZMofCHGhEp8qUMx3PksLfshrk"
    ["Purdue University"]="VMqRkZTWE5pX8AEow5jqYYxn6QkzLBL94woT2etshrk"
    ["University of Minnesota"]="Cw2b2ng2fa78ndCXHcJMT1pqvdGxUHu5EBEB8KBshrk"
    ["Villanova University"]="c3wFuF1LCtsY5DGo7eBQCwLHhtZgAxNwNDrUCqashrk"
    ["University of Oregon"]="MWogB4b5RamyKE4mur8a8iRy63gZqyDfDF7ebDdshrk"
    ["California State University - Fullerton"]="13WYH5onYubA1gnKbnv222oNZ61pNfSXN5EYyvgGshrk"
    ["University of Waterloo"]="gGQb6ZcDG7fsVLWTvXZ1LLoY348tc1zcP2wkh8kshrk"
    ["Georgia Institute of Technology"]="GLB3jUr5zuu79zFuEH3KP7boxtWsjHVyYRBK2SPshrk"
    ["Dalhousie University"]="T6bpj6H6fr9GyKe73DcNjPbGeSk8twDsiNcU4srshrk"
    ["University of Michigan"]="MkyLHecSHN7TBdWgnh2J8KCsEHnsqqbVYSxtGmsshrk"
)

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Function to create data directory if it doesn't exist
ensure_data_dir() {
    if [ ! -d "./data" ]; then
        mkdir -p ./data
        print_color "$BLUE" "Created ./data directory"
    fi
}

# Function to perform SCP operations
download_files() {
    local ip=$1
    local university=$2
    
    print_color "$BLUE" "\nDownloading files from $university ($ip)..."
    
    # Download staked-identity.json
    if scp -r "firedancer@$ip:/home/firedancer/data/staked-identity.json" ./data/; then
        print_color "$GREEN" "✓ Successfully downloaded staked-identity.json"
    else
        print_color "$RED" "✗ Failed to download staked-identity.json"
        return 1
    fi
    
    # Download vote-account-keypair.json
    if scp -r "firedancer@$ip:/home/firedancer/data/vote-account-keypair.json" ./data/; then
        print_color "$GREEN" "✓ Successfully downloaded vote-account-keypair.json"
    else
        print_color "$RED" "✗ Failed to download vote-account-keypair.json"
        return 1
    fi
    
    return 0
}

# Function to validate public keys
validate_keys() {
    local university=$1
    local expected_staked_identity="${STAKED_IDENTITY_ADDRESSES[$university]}"
    local expected_vote_account="${VOTE_ACCOUNT_ADDRESSES[$university]}"
    local validation_failed=0
    
    print_color "$BLUE" "\nValidating public keys..."
    
    # Validate staked-identity.json
    if [ -f "./data/staked-identity.json" ]; then
        local actual_staked_identity=$(solana-keygen pubkey ./data/staked-identity.json 2>/dev/null)
        
        if [ "$actual_staked_identity" == "$expected_staked_identity" ]; then
            print_color "$GREEN" "✓ Staked identity validation PASSED"
            print_color "$GREEN" "  Expected: $expected_staked_identity"
            print_color "$GREEN" "  Actual:   $actual_staked_identity"
        else
            print_color "$RED" "✗ Staked identity validation FAILED"
            print_color "$RED" "  Expected: $expected_staked_identity"
            print_color "$RED" "  Actual:   $actual_staked_identity"
            validation_failed=1
        fi
    else
        print_color "$RED" "✗ staked-identity.json file not found"
        validation_failed=1
    fi
    
    # Validate vote-account-keypair.json
    if [ -f "./data/vote-account-keypair.json" ]; then
        local actual_vote_account=$(solana-keygen pubkey ./data/vote-account-keypair.json 2>/dev/null)
        
        if [ "$actual_vote_account" == "$expected_vote_account" ]; then
            print_color "$GREEN" "✓ Vote account validation PASSED"
            print_color "$GREEN" "  Expected: $expected_vote_account"
            print_color "$GREEN" "  Actual:   $actual_vote_account"
        else
            print_color "$RED" "✗ Vote account validation FAILED"
            print_color "$RED" "  Expected: $expected_vote_account"
            print_color "$RED" "  Actual:   $actual_vote_account"
            validation_failed=1
        fi
    else
        print_color "$RED" "✗ vote-account-keypair.json file not found"
        validation_failed=1
    fi
    
    return $validation_failed
}

# Main script
main() {
    print_color "$YELLOW" "==================================="
    print_color "$YELLOW" " University Solana Key Validator"
    print_color "$YELLOW" "==================================="
    
    # Check if solana-keygen is available
    if ! command -v solana-keygen &> /dev/null; then
        print_color "$RED" "Error: solana-keygen is not installed or not in PATH"
        exit 1
    fi
    
    # Ensure data directory exists
    ensure_data_dir
    
    # Create array of university names for selection
    universities=()
    for university in "${!UNIVERSITY_IPS[@]}"; do
        universities+=("$university")
    done
    
    # Sort the array for better user experience
    IFS=$'\n' sorted_universities=($(sort <<<"${universities[*]}"))
    unset IFS
    
    # Interactive selection menu
    print_color "$BLUE" "\nPlease select a university:"
    PS3="Enter your choice (1-${#sorted_universities[@]}): "
    
    select selected_university in "${sorted_universities[@]}" "Quit"; do
        case $selected_university in
            "Quit")
                print_color "$YELLOW" "Exiting..."
                exit 0
                ;;
            "")
                print_color "$RED" "Invalid selection. Please try again."
                ;;
            *)
                print_color "$GREEN" "\nYou selected: $selected_university"
                
                # Get the IP for the selected university
                ip="${UNIVERSITY_IPS[$selected_university]}"
                
                if [ -z "$ip" ]; then
                    print_color "$RED" "Error: No IP found for $selected_university"
                    exit 1
                fi
                
                print_color "$BLUE" "IP Address: $ip"
                
                # Download files
                if ! download_files "$ip" "$selected_university"; then
                    print_color "$RED" "\nError: Failed to download files from $selected_university"
                    exit 1
                fi
                
                # Validate keys
                if validate_keys "$selected_university"; then
                    print_color "$GREEN" "\n==================================="
                    print_color "$GREEN" "SUCCESS: All validations passed! ✓"
                    print_color "$GREEN" "==================================="
                    exit 0
                else
                    print_color "$RED" "\n==================================="
                    print_color "$RED" "ERROR: Validation failed! ✗"
                    print_color "$RED" "==================================="
                    exit 1
                fi
                ;;
        esac
    done
}

# Run main function
main